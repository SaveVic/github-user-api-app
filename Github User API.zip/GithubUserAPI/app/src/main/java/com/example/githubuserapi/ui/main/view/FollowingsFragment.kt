package com.example.githubuserapi.ui.main.view

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.githubuserapi.R
import com.example.githubuserapi.data.model.QueryUser
import com.example.githubuserapi.databinding.FragmentFollowingsBinding
import com.example.githubuserapi.ui.main.adapter.MainQueryAdapter
import com.example.githubuserapi.ui.main.viewmodel.DetailViewModel
import com.example.githubuserapi.utils.ListLoadStatus

class FollowingsFragment : Fragment() {
    private var binding: FragmentFollowingsBinding? = null
    private var adapter: MainQueryAdapter? = null
    private var detailViewModel: DetailViewModel? = null
    private var emptyMsg = ""
    private var errorMsg = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        detailViewModel = activity?.let { ViewModelProviders.of(it).get(DetailViewModel::class.java) }
        emptyMsg = resources.getString(R.string.status_empty)
        errorMsg = resources.getString(R.string.status_error)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentFollowingsBinding.inflate(inflater, container, false)
        setupUI()
        setupObserver()
        return binding?.root
    }

    private fun setupUI(){
        binding?.followingsRv?.layoutManager = LinearLayoutManager(activity, RecyclerView.VERTICAL, false)
        adapter = MainQueryAdapter(arrayListOf(), false)
        binding?.followingsRv?.adapter = adapter
    }

    private fun renderList(users: List<QueryUser>) {
        adapter?.replaceList(users)
        adapter?.notifyDataSetChanged()
    }

    private fun setupObserver() {
        detailViewModel?.getFollowingsList()?.observe(this, {
            when (it.status) {
                ListLoadStatus.FILLED -> {
                    binding?.followingsLoading?.visibility = View.GONE
                    binding?.followingsStatus?.visibility = View.GONE
                    it.data?.let { users -> renderList(users) }
                    binding?.followingsRv?.visibility = View.VISIBLE
                }
                ListLoadStatus.EMPTY -> {
                    binding?.followingsLoading?.visibility = View.GONE
                    binding?.followingsRv?.visibility = View.GONE
                    binding?.followingsStatus?.text = emptyMsg
                    binding?.followingsStatus?.visibility = View.VISIBLE
                }
                ListLoadStatus.ERROR -> {
                    binding?.followingsLoading?.visibility = View.GONE
                    binding?.followingsRv?.visibility = View.GONE
                    var display = errorMsg
                    it.message?.let { msg ->
                        display += "\n$msg"
                    }
                    binding?.followingsStatus?.text = display
                    binding?.followingsStatus?.visibility = View.VISIBLE
                }
                ListLoadStatus.LOADING -> {
                    binding?.followingsLoading?.visibility = View.VISIBLE
                    binding?.followingsRv?.visibility = View.GONE
                    binding?.followingsStatus?.visibility = View.GONE
                }
            }
        })
    }
}