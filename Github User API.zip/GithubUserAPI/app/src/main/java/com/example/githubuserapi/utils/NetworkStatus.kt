package com.example.githubuserapi.utils

enum class NetworkStatus {
    SUCCESS, ERROR, LOADING
}