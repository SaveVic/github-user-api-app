package com.example.githubuserapi.utils

enum class ListLoadStatus {
    LOADING, FILLED, EMPTY, ERROR
}